using namespace std;
#pragma once
class Calc {
public:
	static double Addition(double num1, double num2);
	static double Subtraction(double num1, double num2);
	static double Multiplication(double num1, double num2);
	static double division(double num1, double num2);
};