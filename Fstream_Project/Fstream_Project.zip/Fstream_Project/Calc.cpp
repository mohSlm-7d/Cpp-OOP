#include<iostream>
#include"Calc.h"
using namespace std;

double Calc::Addition(double num1, double num2){
	return num1 + num2;
}

double Calc::Subtraction(double num1, double num2){
	return num1 - num2;
}

double Calc::Multiplication(double num1, double num2){
	return num1 * num2;
}

double Calc::division(double num1, double num2){
	return num1 / num2;
}
